// Initialisation de la carte
const map = L.map('map').setView([0, 0], 2);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap'
}).addTo(map);

const listePositions = document.getElementById("listePositions");
const canvas = document.getElementById("canvasGraph");
const ctx = canvas.getContext("2d");
let historique = JSON.parse(localStorage.getItem("positions")) || [];

// --- Affichage de l’historique ---
function afficherHistorique() {
  listePositions.innerHTML = "";
  historique.forEach(pos => {
    const li = document.createElement("li");
    li.textContent = `${pos.date} → (${pos.lat.toFixed(4)}, ${pos.lon.toFixed(4)})`;
    listePositions.appendChild(li);
  });
  animerCanvas();
}

// --- Fonction de dessin et animation sur Canvas ---
let t = 0;
function animerCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (historique.length < 2) {
    ctx.fillStyle = "white";
    ctx.font = "18px Arial";
    ctx.fillText("Ajoutez au moins 2 positions pour voir l’animation.", 100, 150);
    return;
  }

  // Normalisation des coordonnées pour Canvas
  const points = historique.map(pos => ({
    x: (pos.lon + 180) * (canvas.width / 360),
    y: (90 - pos.lat) * (canvas.height / 180)
  }));

  // Ligne entre les points
  ctx.beginPath();
  ctx.strokeStyle = "white";
  ctx.lineWidth = 2;
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) {
    ctx.lineTo(points[i].x, points[i].y);
  }
  ctx.stroke();

  // Animation du point rouge
  const segment = Math.floor(t) % (points.length - 1);
  const ratio = t - Math.floor(t);
  const x = points[segment].x + (points[segment + 1].x - points[segment].x) * ratio;
  const y = points[segment].y + (points[segment + 1].y - points[segment].y) * ratio;

  ctx.beginPath();
  ctx.arc(x, y, 8, 0, 2 * Math.PI);
  ctx.fillStyle = "#ff4d4d";
  ctx.fill();

  // Affichage du texte animé
  ctx.fillStyle = "white";
  ctx.font = "14px Arial";
  ctx.fillText("Position animée", x + 10, y - 10);

  // Incrément du temps pour l’animation
  t += 0.02;
  requestAnimationFrame(animerCanvas);
}

// --- Géolocalisation ---
document.getElementById("getLocation").addEventListener("click", () => {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(success, error);
  } else {
    alert("La géolocalisation n'est pas supportée par votre navigateur.");
  }
});

function success(position) {
  const lat = position.coords.latitude;
  const lon = position.coords.longitude;

  map.setView([lat, lon], 13);
  L.marker([lat, lon]).addTo(map).bindPopup("Vous êtes ici 📍").openPopup();

  const date = new Date().toLocaleDateString();
  historique.push({ date, lat, lon });
  localStorage.setItem("positions", JSON.stringify(historique));
  afficherHistorique();
}

function error() {
  alert("Impossible d'obtenir votre position.");
}

// --- Lancement initial ---
afficherHistorique();
