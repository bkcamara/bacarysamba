<?php
require 'config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$reader_id = isset($_GET['reader_id']) ? (int)$_GET['reader_id'] : 1;

// Récupérer les infos du lecteur
$stmt = $mysqli->prepare("SELECT * FROM lecteurs WHERE id = ?");
$stmt->bind_param("i", $reader_id);
$stmt->execute();
$reader = $stmt->get_result()->fetch_assoc();

// Récupérer les livres dans la liste de lecture
$stmt = $mysqli->prepare("
  SELECT ll.id AS ll_id, l.id AS livre_id, l.titre, l.auteur, ll.date_emprunt, ll.date_retour
  FROM liste_lecture ll
  JOIN livres l ON ll.id_livre = l.id
  WHERE ll.id_lecteur = ?
  ORDER BY ll.date_emprunt DESC
");
$stmt->bind_param("i", $reader_id);
$stmt->execute();
$res = $stmt->get_result();
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Ma liste de lecture | Bibliothèque</title>

  <style>
    :root {
      --bg: #f5f7f6;
      --text: #222;
      --card-bg: #fff;
      --accent: #007f5f;
      --accent-dark: #005f48;
      --nav-bg: rgba(0, 78, 100, 0.9);
      --footer-bg: #004e64;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    body.dark {
      --bg: #101414;
      --text: #f0f0f0;
      --card-bg: #1a1e1e;
      --accent: #1abc9c;
      --accent-dark: #159b82;
      --nav-bg: rgba(15, 25, 25, 0.9);
      --footer-bg: #0b0f0f;
      --shadow: rgba(255, 255, 255, 0.05);
    }

    body {
      margin: 0;
      font-family: "Segoe UI", Roboto, sans-serif;
      background: var(--bg);
      color: var(--text);
      transition: background 0.4s, color 0.4s;
    }

    h1 {
      color: var(--accent-dark);
      text-align: center;
    }

    a {
      color: var(--accent);
      text-decoration: none;
    }

    /* === NAVBAR === */
    .navbar {
      background: var(--nav-bg);
      color: #fff;
      padding: 0.8rem 1rem;
      box-shadow: 0 2px 8px var(--shadow);
      position: sticky;
      top: 0;
      z-index: 1000;
      backdrop-filter: blur(6px);
      transition: background 0.4s;
    }

    .navbar-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1100px;
      margin: 0 auto;
    }

    .navbar-logo {
      font-size: 1.4rem;
      font-weight: 600;
      color: #fff;
    }

    .navbar-links {
      list-style: none;
      display: flex;
      gap: 1.3rem;
      margin: 0;
      padding: 0;
      align-items: center;
    }

    .navbar-links li a {
      color: #fff;
      font-weight: 500;
      padding: 0.3rem 0.6rem;
      border-radius: 6px;
      transition: background 0.3s ease;
    }

    .navbar-links li a:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    .toggle-theme {
      background: none;
      border: 2px solid #fff;
      color: #fff;
      border-radius: 50%;
      width: 35px;
      height: 35px;
      font-size: 1.2rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.3s;
    }

    .toggle-theme:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    /* === CONTENU === */
    .container {
      max-width: 900px;
      margin: 2rem auto;
      background: var(--card-bg);
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 2px 10px var(--shadow);
      transition: background 0.4s, box-shadow 0.4s;
    }

    .reader-info {
      text-align: center;
      margin-bottom: 2rem;
      color: #666;
    }

    .wishlist {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .wishlist li {
      background: var(--bg);
      border: 1px solid #ccc;
      border-radius: 10px;
      padding: 1rem;
      margin-bottom: 1rem;
      box-shadow: 0 2px 6px var(--shadow);
      display: flex;
      justify-content: space-between;
      align-items: center;
      transition: transform 0.2s;
    }

    .wishlist li:hover {
      transform: scale(1.02);
      border-color: var(--accent);
    }

    .book-info strong {
      color: var(--accent-dark);
    }

    .actions {
      display: flex;
      gap: 0.5rem;
    }

    .btn {
      background: var(--accent);
      color: #fff;
      padding: 0.5rem 0.9rem;
      border-radius: 6px;
      text-decoration: none;
      font-size: 0.9rem;
      transition: background 0.2s;
      border: none;
      cursor: pointer;
    }

    .btn:hover {
      background: var(--accent-dark);
    }

    .btn.danger {
      background: #c0392b;
    }

    .btn.danger:hover {
      background: #992d22;
    }

    .empty {
      text-align: center;
      color: #777;
      font-size: 1.1rem;
      margin-top: 2rem;
    }

    footer {
      text-align: center;
      background: var(--footer-bg);
      color: #fff;
      padding: 1rem;
      margin-top: 3rem;
      font-size: 0.9rem;
    }
  </style>
</head>

<body>
  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="navbar-container">
      <a href="index.php" class="navbar-logo">📚 Bibliothèque</a>
      <ul class="navbar-links" id="menu">
        <li><a href="index.php">Accueil</a></li>
        <li><a href="books_add.php">Ajouter un livre</a></li>
        <li><a href="results.php">Résultats</a></li>
        <li><a href="wishlist.php?reader_id=1" class="active">Liste de lecture</a></li>
        <li><button class="toggle-theme" id="themeBtn">🌙</button></li>
      </ul>
    </div>
  </nav>

  <!-- CONTENU -->
  <main class="container">
    <h1>📖 Ma liste de lecture</h1>

    <div class="reader-info">
      <?php if ($reader): ?>
        👤 <strong><?= htmlspecialchars($reader['prenom'] . ' ' . $reader['nom']) ?></strong><br>
        📧 <?= htmlspecialchars($reader['email']) ?>
      <?php else: ?>
        ⚠️ Lecteur inconnu (ID : <?= $reader_id ?>)
      <?php endif; ?>
    </div>

    <?php if ($res->num_rows === 0): ?>
      <p class="empty">Aucun livre dans votre liste de lecture.</p>
    <?php else: ?>
      <ul class="wishlist">
        <?php while ($row = $res->fetch_assoc()): ?>
          <li>
            <div class="book-info">
              <strong><?= htmlspecialchars($row['titre']) ?></strong><br>
              <small><?= htmlspecialchars($row['auteur']) ?></small><br>
              <small>📅 Emprunté le : <?= $row['date_emprunt'] ?: '—' ?></small>
            </div>
            <div class="actions">
              <a href="details.php?id=<?= $row['livre_id'] ?>&reader_id=<?= $reader_id ?>" class="btn">Voir</a>
              <form action="remove_from_wishlist.php" method="post" style="margin:0;">
                <input type="hidden" name="id" value="<?= $row['ll_id'] ?>">
                <input type="hidden" name="reader_id" value="<?= $reader_id ?>">
                <button type="submit" class="btn danger" onclick="return confirm('Supprimer ce livre ?')">Retirer</button>
              </form>
            </div>
          </li>
        <?php endwhile; ?>
      </ul>
    <?php endif; ?>
  </main><br><br><br><br><br><br><br>

  <footer>
    &copy; 2025 Bibliothèque – Tous droits réservés by Bacary Samba Camara.
  </footer>

  <script>
    // 🌙 Mode sombre / clair
    document.addEventListener("DOMContentLoaded", () => {
      const themeBtn = document.getElementById('themeBtn');
      const body = document.body;

      function applyTheme(isDark) {
        if (isDark) {
          body.classList.add('dark');
          themeBtn.textContent = '☀️';
          localStorage.setItem('theme', 'dark');
        } else {
          body.classList.remove('dark');
          themeBtn.textContent = '🌙';
          localStorage.setItem('theme', 'light');
        }
      }

      if (localStorage.getItem('theme') === 'dark') {
        applyTheme(true);
      }

      themeBtn.addEventListener('click', () => {
        const isDark = !body.classList.contains('dark');
        applyTheme(isDark);
      });
    });
  </script>
</body>
</html>
