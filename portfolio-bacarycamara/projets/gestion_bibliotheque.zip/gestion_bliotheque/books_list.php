<?php
require 'config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$message = '';

// Suppression
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $mysqli->prepare("DELETE FROM livres WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $message = "<div class='success-msg'>✅ Livre supprimé avec succès.</div>";
    } else {
        $message = "<div class='error-msg'>❌ Erreur lors de la suppression.</div>";
    }
}

// Récupération des livres
$result = $mysqli->query("SELECT * FROM livres ORDER BY id DESC");
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Gestion des livres | Bibliothèque</title>

  <style>
    :root {
      --bg: #f5f7f6;
      --text: #222;
      --card-bg: #fff;
      --accent: #007f5f;
      --accent-dark: #005f48;
      --nav-bg: rgba(0, 78, 100, 0.9);
      --footer-bg: #004e64;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    body.dark {
      --bg: #101414;
      --text: #f0f0f0;
      --card-bg: #1a1e1e;
      --accent: #1abc9c;
      --accent-dark: #159b82;
      --nav-bg: rgba(15, 25, 25, 0.9);
      --footer-bg: #0b0f0f;
      --shadow: rgba(255, 255, 255, 0.05);
    }

    body {
      margin: 0;
      font-family: "Segoe UI", Roboto, sans-serif;
      background: var(--bg);
      color: var(--text);
      transition: background 0.4s, color 0.4s;
    }

    h1 {
      color: var(--accent-dark);
      text-align: center;
    }

    a {
      color: var(--accent);
      text-decoration: none;
    }

    /* === NAVBAR === */
    .navbar {
      background: var(--nav-bg);
      color: #fff;
      padding: 0.8rem 1rem;
      box-shadow: 0 2px 8px var(--shadow);
      position: sticky;
      top: 0;
      z-index: 1000;
      backdrop-filter: blur(6px);
      transition: background 0.4s;
    }

    .navbar-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1100px;
      margin: 0 auto;
    }

    .navbar-logo {
      font-size: 1.4rem;
      font-weight: 600;
      color: #fff;
    }

    .navbar-links {
      list-style: none;
      display: flex;
      gap: 1.3rem;
      margin: 0;
      padding: 0;
      align-items: center;
    }

    .navbar-links li a {
      color: #fff;
      font-weight: 500;
      padding: 0.3rem 0.6rem;
      border-radius: 6px;
      transition: background 0.3s ease;
    }

    .navbar-links li a:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    .toggle-theme {
      background: none;
      border: 2px solid #fff;
      color: #fff;
      border-radius: 50%;
      width: 35px;
      height: 35px;
      font-size: 1.2rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.3s;
    }

    .toggle-theme:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    /* === CONTENU === */
    .container {
      max-width: 1000px;
      margin: 2.5rem auto;
      background: var(--card-bg);
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 2px 10px var(--shadow);
      transition: background 0.4s, box-shadow 0.4s;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 1.5rem;
    }

    th, td {
      border: 1px solid #ccc;
      padding: 0.8rem;
      text-align: left;
    }

    th {
      background: var(--accent);
      color: #fff;
    }

    tr:nth-child(even) {
      background: rgba(0, 0, 0, 0.03);
    }

    .actions a {
      margin-right: 0.5rem;
      text-decoration: none;
      padding: 0.4rem 0.8rem;
      border-radius: 6px;
      font-size: 0.9rem;
      color: #fff;
    }

    .edit {
      background: #3498db;
    }

    .edit:hover {
      background: #217dbb;
    }

    .delete {
      background: #c0392b;
    }

    .delete:hover {
      background: #992d22;
    }

    .success-msg, .error-msg {
      margin: 1rem auto;
      padding: 0.8rem 1rem;
      border-radius: 8px;
      font-weight: 500;
      max-width: 700px;
      text-align: center;
    }

    .success-msg {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .error-msg {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    footer {
      text-align: center;
      margin-top: 3rem;
      padding: 1rem;
      background: var(--footer-bg);
      color: #fff;
      font-size: 0.9rem;
    }
  </style>
</head>

<body>
  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="navbar-container">
      <a href="index.php" class="navbar-logo">📚 Bibliothèque</a>
      <ul class="navbar-links" id="menu">
        <li><a href="index.php">Accueil</a></li>
        <li><a href="books_add.php">Ajouter</a></li>
        <li><a href="books_list.php" class="active">Liste des livres</a></li>
        <li><a href="wishlist.php?reader_id=1">Liste de lecture</a></li>
        <li><button class="toggle-theme" id="themeBtn">🌙</button></li>
      </ul>
    </div>
  </nav>

  <!-- CONTENU -->
  <main class="container">
    <h1>📘 Gestion des livres</h1>
    <?= $message ?>

    <?php if ($result->num_rows === 0): ?>
      <p style="text-align:center;color:#777;">Aucun livre enregistré pour le moment.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Titre</th>
            <th>Auteur</th>
            <th>Maison d’édition</th>
            <th>Exemplaires</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= $row['id'] ?></td>
              <td><?= htmlspecialchars($row['titre']) ?></td>
              <td><?= htmlspecialchars($row['auteur']) ?></td>
              <td><?= htmlspecialchars($row['maison_edition']) ?></td>
              <td><?= $row['nombre_exemplaire'] ?></td>
              <td class="actions">
                <a href="books_edit.php?id=<?= $row['id'] ?>" class="edit">✏️ Modifier</a>
                <a href="?delete=<?= $row['id'] ?>" class="delete" onclick="return confirm('Supprimer ce livre ?')">🗑️ Supprimer</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </main>

  <footer>
    &copy; 2025 Bibliothèque – Tous droits réservés by Bacary Samba Camara.
  </footer>

  <script>
    // Mode sombre / clair
    document.addEventListener("DOMContentLoaded", () => {
      const themeBtn = document.getElementById('themeBtn');
      const body = document.body;

      function applyTheme(isDark) {
        if (isDark) {
          body.classList.add('dark');
          themeBtn.textContent = '☀️';
          localStorage.setItem('theme', 'dark');
        } else {
          body.classList.remove('dark');
          themeBtn.textContent = '🌙';
          localStorage.setItem('theme', 'light');
        }
      }

      if (localStorage.getItem('theme') === 'dark') {
        applyTheme(true);
      }

      themeBtn.addEventListener('click', () => {
        const isDark = !body.classList.contains('dark');
        applyTheme(isDark);
      });
    });
  </script>
</body>
</html>
