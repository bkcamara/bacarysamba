<?php
// remove_from_wishlist.php
require 'config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.html');
    exit;
}
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$reader = isset($_POST['reader_id']) ? (int)$_POST['reader_id'] : 1;
if ($id <= 0) die('ID invalide.');

$stmt = $mysqli->prepare("DELETE FROM liste_lecture WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
header("Location: wishlist.php?reader_id={$reader}");
exit;
