<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Bibliothèque en ligne</title>

  <style>
    :root {
      --bg: #f5f7f6;
      --text: #222;
      --card-bg: #fff;
      --accent: #007f5f;
      --accent-dark: #005f48;
      --nav-bg: rgba(0, 78, 100, 0.9);
      --footer-bg: #004e64;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    body.dark {
      --bg: #101414;
      --text: #f0f0f0;
      --card-bg: #1a1e1e;
      --accent: #1abc9c;
      --accent-dark: #159b82;
      --nav-bg: rgba(15, 25, 25, 0.9);
      --footer-bg: #0b0f0f;
      --shadow: rgba(255, 255, 255, 0.05);
    }

    /* === BASE === */
    body {
      margin: 0;
      font-family: "Segoe UI", Roboto, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.6;
      transition: background 0.4s, color 0.4s;
    }

    h1, h2, h3 {
      color: var(--accent-dark);
      transition: color 0.4s;
    }

    a {
      text-decoration: none;
      color: var(--accent);
      transition: color 0.4s;
    }

    /* === NAVBAR === */
    .navbar {
      background: var(--nav-bg);
      color: #fff;
      padding: 0.8rem 1rem;
      box-shadow: 0 2px 8px var(--shadow);
      position: sticky;
      top: 0;
      z-index: 1000;
      backdrop-filter: blur(6px);
      transition: background 0.4s;
    }

    .navbar-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1100px;
      margin: 0 auto;
    }

    .navbar-logo {
      font-size: 1.4rem;
      font-weight: 600;
      color: #fff;
    }

    .navbar-links {
      list-style: none;
      display: flex;
      gap: 1.3rem;
      margin: 0;
      padding: 0;
      align-items: center;
    }

    .navbar-links li a {
      color: #fff;
      font-weight: 500;
      padding: 0.3rem 0.6rem;
      border-radius: 6px;
      transition: background 0.3s ease;
    }

    .navbar-links li a:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    .navbar-toggle {
      display: none;
      font-size: 1.5rem;
      color: #fff;
      background: none;
      border: none;
      cursor: pointer;
    }

    /* === BOUTON MODE NUIT === */
    .toggle-theme {
      background: none;
      border: 2px solid #fff;
      color: #fff;
      border-radius: 50%;
      width: 35px;
      height: 35px;
      font-size: 1.2rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.3s;
    }

    .toggle-theme:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    @media (max-width: 768px) {
      .navbar-toggle {
        display: block;
      }

      .navbar-links {
        position: absolute;
        top: 60px;
        right: 15px;
        background: var(--nav-bg);
        flex-direction: column;
        width: 200px;
        border-radius: 10px;
        padding: 1rem;
        display: none;
      }

      .navbar-links.active {
        display: flex;
      }
    }


    .hero {
      position: relative;
      background: linear-gradient(rgba(0, 78, 100, 0.6), rgba(0, 78, 100, 0.8)),
                  url('https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat;
      color: white;
      text-align: center;
      padding: 6rem 1.5rem;
      border-bottom-left-radius: 50% 10%;
      border-bottom-right-radius: 50% 10%;
      box-shadow: 0 4px 12px rgba(0,0,0,0.25);
      transition: background 0.4s;
    }

    .hero h1 {
      font-size: 2.6rem;
      margin-bottom: 1rem;
      text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
    }

    .hero p {
      font-size: 1.15rem;
      max-width: 650px;
      margin: 0 auto;
      color: #e8f5f2;
    }

    /* === RECHERCHE === */
    .search-section {
      max-width: 750px;
      background: var(--card-bg);
      margin: -2.5rem auto 3rem auto;
      padding: 2.2rem;
      border-radius: 15px;
      box-shadow: 0 5px 15px var(--shadow);
      position: relative;
      z-index: 10;
      transition: background 0.4s, box-shadow 0.4s;
    }

    .search-section h2 {
      text-align: center;
      margin-bottom: 1rem;
    }

    .search-form {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 0.8rem;
    }

    .search-form input,
    .search-form select {
      padding: 0.7rem;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 1rem;
      flex: 1 1 250px;
      background: var(--bg);
      color: var(--text);
    }

    .search-form button {
      background: var(--accent);
      color: #fff;
      border: none;
      padding: 0.7rem 1.2rem;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }

    .search-form button:hover {
      background: var(--accent-dark);
    }

    .helper {
      text-align: center;
      font-size: 0.95rem;
      color: #666;
      margin-top: 0.8rem;
    }

   
    .howto {
      max-width: 900px;
      margin: 3rem auto;
      background: var(--card-bg);
      padding: 2.5rem;
      border-radius: 12px;
      box-shadow: 0 2px 8px var(--shadow);
      transition: background 0.4s, box-shadow 0.4s;
    }

    .howto h3 {
      text-align: center;
      margin-bottom: 1.5rem;
    }

    .howto ol {
      line-height: 1.8;
      font-size: 1rem;
      color: var(--text);
      max-width: 700px;
      margin: 0 auto;
    }

    .howto li::marker {
      color: var(--accent);
      font-weight: bold;
    }

    /* === FOOTER === */
    footer {
      text-align: center;
      background: var(--footer-bg);
      color: white;
      padding: 1.5rem;
      margin-top: 3rem;
      font-size: 0.95rem;
      transition: background 0.4s;
    }

    footer a {
      color: #fdd835;
      font-weight: 600;
    }
  </style>
</head>

<body>
  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="navbar-container">
      <a href="index.php" class="navbar-logo">📚 Bibliothèque</a>
      <button class="navbar-toggle" id="menu-btn">☰</button>
      <ul class="navbar-links" id="menu">
        <li><a href="index.php" class="active">Accueil</a></li>
        <li><a href="books_add.php">Ajouter un livre</a></li>
        <li><a href="books_list.php">gestion</a></li>
        <li><a href="results.php">Résultats</a></li>
        <li><a href="wishlist.php?reader_id=1">Liste de lecture</a></li>
        <li><button class="toggle-theme" id="themeBtn">🌙</button></li>
      </ul>
    </div>
  </nav>

  <section class="hero">
    <h1>Bienvenue à la Bibliothèque en ligne de Camara Bacary 📖</h1>
    <p>Explorez, découvrez et gérez vos livres préférés — en mode clair ou sombre !</p>
  </section>

  <!-- RECHERCHE -->
  <section class="search-section">
    <h2>🔍 Rechercher un livre</h2>
    <form action="results.php" method="get" class="search-form">
      <input type="text" name="q" placeholder="Titre ou auteur..." required>
      <select name="field">
        <option value="all">Titre ou auteur</option>
        <option value="titre">Titre</option>
        <option value="auteur">Auteur</option>
      </select>
      <button type="submit">Rechercher</button>
    </form>

  </section>

 
  <section class="howto">
    <h3> Comment utiliser Bibliothèque</h3>
    <ol>
      <li>Recherchez un livre via le formulaire ci-dessus.</li>
      <li>Cliquez sur “Détails” pour consulter sa fiche.</li>
      <li>Ajoutez le livre à votre liste de lecture.</li>
      <li>Activez le mode nuit 🌙 pour une lecture confortable le soir.</li>
    </ol>
  </section>


  <footer>
    📩 Contact : <a href="mailto:beranoicamara@gmail.com">beranoicamara@gmail.com</a><br>
    <small>&copy; 2025 Bibliothèque en ligne – Tous droits réservés by Bacary Samba Camara.</small>
  </footer>

  <script>
    // Menu mobile
    const menuBtn = document.getElementById('menu-btn');
    const menu = document.getElementById('menu');
    menuBtn.addEventListener('click', () => menu.classList.toggle('active'));

    // Thème (clair/sombre)
    const themeBtn = document.getElementById('themeBtn');
    const body = document.body;

    function applyTheme(isDark) {
      if (isDark) {
        body.classList.add('dark');
        themeBtn.textContent = '☀️';
        localStorage.setItem('theme', 'dark');
      } else {
        body.classList.remove('dark');
        themeBtn.textContent = '🌙';
        localStorage.setItem('theme', 'light');
      }
    }

    themeBtn.addEventListener('click', () => {
      const isDark = !body.classList.contains('dark');
      applyTheme(isDark);
    });

    // Charger le thème précédent
    if (localStorage.getItem('theme') === 'dark') {
      applyTheme(true);
    }
  </script>
</body>
</html>
