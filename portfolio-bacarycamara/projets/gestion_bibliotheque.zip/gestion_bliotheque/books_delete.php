<?php
// books_delete.php
require 'config.php';
if (!isset($_GET['id'])) die('ID manquant');
$id = (int)$_GET['id'];



$stmt = $mysqli->prepare("DELETE FROM livres WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
header('Location: results.php');
exit;
