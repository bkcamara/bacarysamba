<!-- navbar.php -->
<nav class="navbar">
  <div class="navbar-container">
    <a href="index.html" class="navbar-logo">📚 <span>Bibliothèque</span></a>

    <button class="navbar-toggle" id="menu-btn">☰</button>

    <ul class="navbar-links" id="menu">
      <li><a href="index.php">Accueil</a></li>
      <li><a href="books_add.php">Ajouter un livre</a></li>
      <li><a href="results.php">Résultats</a></li>
      <li><a href="wishlist.php?reader_id=1">Liste de lecture</a></li>
      <li><a href="#contact">Contact</a></li>
    </ul>
  </div>
</nav>
