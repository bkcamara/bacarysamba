<?php
// add_to_wishlist.php
require 'config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.html');
    exit;
}


$id_livre = isset($_POST['id_livre']) ? (int)$_POST['id_livre'] : 0;
$id_lecteur = isset($_POST['id_lecteur']) ? (int)$_POST['id_lecteur'] : 0;
$date_emprunt = !empty($_POST['date_emprunt']) ? $_POST['date_emprunt'] : null;

if ($id_livre <= 0 || $id_lecteur <= 0) {
    die('Données invalides.');
}


$stmt = $mysqli->prepare("SELECT id FROM liste_lecture WHERE id_livre = ? AND id_lecteur = ?");
$stmt->bind_param("ii", $id_livre, $id_lecteur);
$stmt->execute();
$exists = $stmt->get_result()->fetch_assoc();
if ($exists) {
    // rediriger vers wishlist
    header("Location: wishlist.php?reader_id={$id_lecteur}");
    exit;
}

$stmt = $mysqli->prepare("INSERT INTO liste_lecture (id_livre, id_lecteur, date_emprunt) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $id_livre, $id_lecteur, $date_emprunt);
$ok = $stmt->execute();
if (!$ok) {
    die('Erreur lors de l\'ajout : ' . $mysqli->error);
}
header("Location: wishlist.php?reader_id={$id_lecteur}");
exit;
