<?php
require 'config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = trim($_POST['titre']);
    $auteur = trim($_POST['auteur']);
    $maison = trim($_POST['maison_edition']);
    $nb = (int)$_POST['nombre_exemplaire'];
    $description = trim($_POST['description']);

    if ($titre && $auteur) {
        $stmt = $mysqli->prepare("INSERT INTO livres (titre, auteur, description, maison_edition, nombre_exemplaire)
                                  VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $titre, $auteur, $description, $maison, $nb);
        if ($stmt->execute()) {
            $message = "<div class='success-msg'>✅ Livre ajouté avec succès.</div>";
        } else {
            $message = "<div class='error-msg'>❌ Erreur lors de l’ajout : " . htmlspecialchars($stmt->error) . "</div>";
        }
    } else {
        $message = "<div class='error-msg'>⚠️ Le titre et l’auteur sont obligatoires.</div>";
    }
}
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Ajouter un livre | Bibliothèque</title>

  <style>
    :root {
      --bg: #f5f7f6;
      --text: #222;
      --card-bg: #fff;
      --accent: #007f5f;
      --accent-dark: #005f48;
      --nav-bg: rgba(0, 78, 100, 0.9);
      --footer-bg: #004e64;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    body.dark {
      --bg: #101414;
      --text: #f0f0f0;
      --card-bg: #1a1e1e;
      --accent: #1abc9c;
      --accent-dark: #159b82;
      --nav-bg: rgba(15, 25, 25, 0.9);
      --footer-bg: #0b0f0f;
      --shadow: rgba(255, 255, 255, 0.05);
    }

    body {
      margin: 0;
      font-family: "Segoe UI", Roboto, sans-serif;
      background: var(--bg);
      color: var(--text);
      transition: background 0.4s, color 0.4s;
    }

    h1 {
      color: var(--accent-dark);
      text-align: center;
    }

    a {
      color: var(--accent);
      text-decoration: none;
    }

    /* === NAVBAR === */
    .navbar {
      background: var(--nav-bg);
      color: #fff;
      padding: 0.8rem 1rem;
      box-shadow: 0 2px 8px var(--shadow);
      position: sticky;
      top: 0;
      z-index: 1000;
      backdrop-filter: blur(6px);
      transition: background 0.4s;
    }

    .navbar-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1100px;
      margin: 0 auto;
    }

    .navbar-logo {
      font-size: 1.4rem;
      font-weight: 600;
      color: #fff;
    }

    .navbar-links {
      list-style: none;
      display: flex;
      gap: 1.3rem;
      margin: 0;
      padding: 0;
      align-items: center;
    }

    .navbar-links li a {
      color: #fff;
      font-weight: 500;
      padding: 0.3rem 0.6rem;
      border-radius: 6px;
      transition: background 0.3s ease;
    }

    .navbar-links li a:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    .toggle-theme {
      background: none;
      border: 2px solid #fff;
      color: #fff;
      border-radius: 50%;
      width: 35px;
      height: 35px;
      font-size: 1.2rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.3s;
    }

    .toggle-theme:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    @media (max-width: 768px) {
      .navbar-links {
        position: absolute;
        top: 60px;
        right: 15px;
        background: var(--nav-bg);
        flex-direction: column;
        width: 200px;
        border-radius: 10px;
        padding: 1rem;
        display: none;
      }

      .navbar-links.active {
        display: flex;
      }
    }

    /* === FORMULAIRE === */
    .container {
      max-width: 700px;
      margin: 2.5rem auto;
      background: var(--card-bg);
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 2px 10px var(--shadow);
      transition: background 0.4s, box-shadow 0.4s;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      margin-bottom: 1rem;
    }

    .form-group label {
      font-weight: 600;
      margin-bottom: 0.3rem;
    }

    .form-group input,
    .form-group textarea {
      padding: 0.6rem;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 1rem;
      background: var(--bg);
      color: var(--text);
      transition: border-color 0.2s;
    }

    .form-group input:focus,
    .form-group textarea:focus {
      border-color: var(--accent);
      outline: none;
    }

    .form-actions {
      display: flex;
      justify-content: center;
      margin-top: 1.5rem;
    }

    .btn {
      background: var(--accent);
      color: #fff;
      border: none;
      padding: 0.7rem 1.4rem;
      border-radius: 8px;
      font-size: 1rem;
      cursor: pointer;
      transition: background 0.2s;
    }

    .btn:hover {
      background: var(--accent-dark);
    }

    .success-msg, .error-msg {
      margin: 1rem auto;
      padding: 0.8rem 1rem;
      border-radius: 8px;
      font-weight: 500;
      max-width: 600px;
      text-align: center;
    }

    .success-msg {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .error-msg {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    footer {
      text-align: center;
      margin-top: 3rem;
      padding: 1rem;
      background: var(--footer-bg);
      color: #fff;
      font-size: 0.9rem;
    }
  </style>
</head>

<body>
  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="navbar-container">
      <a href="index.php" class="navbar-logo">📚 Bibliothèque</a>
      <ul class="navbar-links" id="menu">
        <li><a href="index.php">Accueil</a></li>
        <li><a href="books_add.php" class="active">Ajouter un livre</a></li>
        <li><a href="results.php">Résultats</a></li>
        <li><a href="wishlist.php?reader_id=1">Liste de lecture</a></li>
        <li><button class="toggle-theme" id="themeBtn">🌙</button></li>
      </ul>
    </div>
  </nav>

  <!-- CONTENU -->
  <main class="container">
    <h1>Ajouter un nouveau livre</h1>
    <?= $message ?>

    <form method="post">
      <div class="form-group">
        <label for="titre">Titre du livre *</label>
        <input type="text" name="titre" id="titre" required>
      </div>

      <div class="form-group">
        <label for="auteur">Auteur *</label>
        <input type="text" name="auteur" id="auteur" required>
      </div>

      <div class="form-group">
        <label for="maison_edition">Maison d’édition</label>
        <input type="text" name="maison_edition" id="maison_edition">
      </div>

      <div class="form-group">
        <label for="nombre_exemplaire">Nombre d’exemplaires</label>
        <input type="number" name="nombre_exemplaire" id="nombre_exemplaire" value="1" min="1">
      </div>

      <div class="form-group">
        <label for="description">Description</label>
        <textarea name="description" id="description" rows="4"></textarea>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn">Ajouter le livre</button>
      </div>
    </form>
  </main>

  <footer>
    &copy; 2025 Bibliothèque – Tous droits réservésby Bacary Samba Camara.
  </footer>

  <script>
    //  Mode sombre / clair
    document.addEventListener("DOMContentLoaded", () => {
      const themeBtn = document.getElementById('themeBtn');
      const body = document.body;

      function applyTheme(isDark) {
        if (isDark) {
          body.classList.add('dark');
          themeBtn.textContent = '☀️';
          localStorage.setItem('theme', 'dark');
        } else {
          body.classList.remove('dark');
          themeBtn.textContent = '🌙';
          localStorage.setItem('theme', 'light');
        }
      }

      if (localStorage.getItem('theme') === 'dark') {
        applyTheme(true);
      }

      themeBtn.addEventListener('click', () => {
        const isDark = !body.classList.contains('dark');
        applyTheme(isDark);
      });
    });
  </script>
</body>
</html>
