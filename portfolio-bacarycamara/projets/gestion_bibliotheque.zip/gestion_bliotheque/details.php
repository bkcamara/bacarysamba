<?php
require 'config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$reader_id = isset($_GET['reader_id']) ? (int)$_GET['reader_id'] : 1;

$stmt = $mysqli->prepare("SELECT * FROM livres WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$book = $res->fetch_assoc();
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Détails du livre | Bibliothèque</title>

  <style>
    :root {
      --bg: #f5f7f6;
      --text: #222;
      --card-bg: #fff;
      --accent: #007f5f;
      --accent-dark: #005f48;
      --nav-bg: rgba(0, 78, 100, 0.9);
      --footer-bg: #004e64;
      --shadow: rgba(0, 0, 0, 0.1);
    }

    body.dark {
      --bg: #101414;
      --text: #f0f0f0;
      --card-bg: #1a1e1e;
      --accent: #1abc9c;
      --accent-dark: #159b82;
      --nav-bg: rgba(15, 25, 25, 0.9);
      --footer-bg: #0b0f0f;
      --shadow: rgba(255, 255, 255, 0.05);
    }

    body {
      margin: 0;
      font-family: "Segoe UI", Roboto, sans-serif;
      background: var(--bg);
      color: var(--text);
      transition: background 0.4s, color 0.4s;
    }

    h1, h2 {
      color: var(--accent-dark);
    }

    a {
      color: var(--accent);
      text-decoration: none;
    }

    /* === NAVBAR === */
    .navbar {
      background: var(--nav-bg);
      color: #fff;
      padding: 0.8rem 1rem;
      box-shadow: 0 2px 8px var(--shadow);
      position: sticky;
      top: 0;
      z-index: 1000;
      backdrop-filter: blur(6px);
      transition: background 0.4s;
    }

    .navbar-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1100px;
      margin: 0 auto;
    }

    .navbar-logo {
      font-size: 1.4rem;
      font-weight: 600;
      color: #fff;
    }

    .navbar-links {
      list-style: none;
      display: flex;
      gap: 1.3rem;
      margin: 0;
      padding: 0;
      align-items: center;
    }

    .navbar-links li a {
      color: #fff;
      font-weight: 500;
      padding: 0.3rem 0.6rem;
      border-radius: 6px;
      transition: background 0.3s ease;
    }

    .navbar-links li a:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    .toggle-theme {
      background: none;
      border: 2px solid #fff;
      color: #fff;
      border-radius: 50%;
      width: 35px;
      height: 35px;
      font-size: 1.2rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.3s;
    }

    .toggle-theme:hover {
      background: rgba(255, 255, 255, 0.2);
    }

    /* === CONTENU === */
    .container {
      max-width: 800px;
      margin: 2rem auto;
      background: var(--card-bg);
      padding: 2.5rem;
      border-radius: 12px;
      box-shadow: 0 2px 10px var(--shadow);
      transition: background 0.4s, box-shadow 0.4s;
    }

    .book-details h1 {
      text-align: center;
      margin-bottom: 1.5rem;
    }

    .book-meta {
      color: #666;
      font-size: 0.95rem;
      margin-bottom: 1rem;
      text-align: center;
    }

    .book-description {
      margin-top: 1rem;
      line-height: 1.6;
      color: var(--text);
    }

    .actions {
      text-align: center;
      margin-top: 2rem;
    }

    .btn {
      background: var(--accent);
      color: #fff;
      border: none;
      padding: 0.7rem 1.4rem;
      border-radius: 8px;
      font-size: 1rem;
      cursor: pointer;
      transition: background 0.2s;
      text-decoration: none;
      display: inline-block;
    }

    .btn:hover {
      background: var(--accent-dark);
    }

    footer {
      text-align: center;
      margin-top: 3rem;
      padding: 1rem;
      background: var(--footer-bg);
      color: #fff;
      font-size: 0.9rem;
    }
  </style>
</head>

<body>
  <!-- NAVBAR -->
  <nav class="navbar">
    <div class="navbar-container">
      <a href="index.php" class="navbar-logo">📚 Bibliothèque</a>
      <ul class="navbar-links" id="menu">
        <li><a href="index.php">Accueil</a></li>
        <li><a href="books_add.php">Ajouter un livre</a></li>
        <li><a href="results.php">Résultats</a></li>
        <li><a href="wishlist.php?reader_id=1">Liste de lecture</a></li>
        <li><button class="toggle-theme" id="themeBtn">🌙</button></li>
      </ul>
    </div>
  </nav>

  <!-- CONTENU -->
  <main class="container">
    <?php if ($book): ?>
      <div class="book-details">
        <h1><?= htmlspecialchars($book['titre']) ?></h1>
        <p class="book-meta">
          Auteur : <strong><?= htmlspecialchars($book['auteur']) ?></strong><br>
          Maison d’édition : <?= htmlspecialchars($book['maison_edition']) ?><br>
          Nombre d’exemplaires : <?= htmlspecialchars($book['nombre_exemplaire']) ?>
        </p>

        <div class="book-description">
          <?= nl2br(htmlspecialchars($book['description'])) ?>
        </div>

        <div class="actions">
          <form action="add_to_wishlist.php" method="post">
            <input type="hidden" name="id_livre" value="<?= $book['id'] ?>">
            <input type="hidden" name="id_lecteur" value="<?= $reader_id ?>">
            <button type="submit" class="btn">➕ Ajouter à ma liste de lecture</button>
          </form>
          <br>
          <a href="results.php" class="btn" style="background:#555;">⬅ Retour</a>
        </div>
      </div>
    <?php else: ?>
      <h2>❌ Livre introuvable</h2>
      <p><a href="results.php" class="btn">Retour à la liste</a></p>
    <?php endif; ?>
  </main><br><br><br><br><br><br><br>

  <footer>
    &copy; 2025 Bibliothèque – Tous droits réservés by Bacary Samba Camara.
  </footer>

  <script>
    //  Mode sombre / clair
    document.addEventListener("DOMContentLoaded", () => {
      const themeBtn = document.getElementById('themeBtn');
      const body = document.body;

      function applyTheme(isDark) {
        if (isDark) {
          body.classList.add('dark');
          themeBtn.textContent = '☀️';
          localStorage.setItem('theme', 'dark');
        } else {
          body.classList.remove('dark');
          themeBtn.textContent = '🌙';
          localStorage.setItem('theme', 'light');
        }
      }

      if (localStorage.getItem('theme') === 'dark') {
        applyTheme(true);
      }

      themeBtn.addEventListener('click', () => {
        const isDark = !body.classList.contains('dark');
        applyTheme(isDark);
      });
    });
  </script>
</body>
</html>
